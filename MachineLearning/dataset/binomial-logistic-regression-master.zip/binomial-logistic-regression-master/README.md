# binomial-logistic-regression
This repository contains the implementation of logistic regression for 2 classes in numpy using jupyter notebook
