# Text classification using Naive Bayes Algorithm¶

Text classification using Naive Bayes Algorithm¶

## Visualizing Confusion Matrix and Heatmap

![Screenshot](images/1.png)

## Sample Text Prediction
    predictCategory('killigs on the streets')
    'talk.politics.guns'
