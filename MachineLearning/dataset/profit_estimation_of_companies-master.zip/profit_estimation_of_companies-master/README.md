# profit estimation of companies using linear regression

profit estimation of companies with linear regression

## Visualizing data before processing

![Screenshot](images/1.png)


## r2_score

0.9209536193310004
