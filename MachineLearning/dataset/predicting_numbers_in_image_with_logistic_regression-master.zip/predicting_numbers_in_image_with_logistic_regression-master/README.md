# predicting numbers in image with logistic regression

predicting numbers in image with logistic regression

## Visualizing Image before processing

![Screenshot](images/1.png)


### Confusion matrix heatmap

![Screenshot](images/2.png)

### Result of Sample correctly predicted 

![Screenshot](images/3.png)


### Accuracy

0.9466666666666667

